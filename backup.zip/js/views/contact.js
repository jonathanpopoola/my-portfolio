define([
	'jquery',
	'underscore',
	'backbone',
	'text!templates/contact.html',
	
],function($, _, Backbone, contact) {
	var contactView = Backbone.View.extend({
		el : $('#mainContainer'),
		
		initialize : function() {
			
		},
		

		render : function() {
			$("#wrap").addClass("contactBody");
			//$(".mainContainer").css();
			this.$el.html(contact);
			
		},
		
		postRender : function() {
			corodinator.trigger('some:channel', 'contact');
	
		}
		
	});
	return new contactView;
});
